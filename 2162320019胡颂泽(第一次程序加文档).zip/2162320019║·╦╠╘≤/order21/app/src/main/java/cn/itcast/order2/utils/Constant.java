package cn.itcast.order2.utils;

public class Constant {
    public  static final String WEB_SIZE="http://192.168.174.1:8080/order";//内网地址
    public  static final String REQUEST_SHOP_URL="/shop_list_data.json";//店铺列表接口
}
